document.addEventListener('DOMContentLoaded', () => {
    const uploadBtn = document.getElementById('upload-btn');
    const cameraBtn = document.getElementById('camera-btn');
    const uploadPanel = document.getElementById('upload-panel');
    const cameraPanel = document.getElementById('camera-panel');
    const fileInput = document.getElementById('file-input');
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const uploadOutput = document.getElementById('upload-output');
    const cameraOutput = document.getElementById('camera-output');
    const switchToCamera = document.getElementById('switch-to-camera');
    const switchToUpload = document.getElementById('switch-to-upload');
    const loadingIndicator = document.getElementById('loading-indicator');
    const startCamera = document.getElementById('start-camera');
    const stopCamera = document.getElementById('stop-camera');
    const errorMessage = document.getElementById('error-message');

    let streaming = false;
    let captureInterval;

    const processImage = async (base64Image, outputElement) => {
        try {
            loadingIndicator.style.display = 'block';
            const response = await fetch('/process_image', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image: base64Image })
            });
            
            const data = await response.json();
            loadingIndicator.style.display = 'none';
            
            if (!response.ok || data.error) {
                throw new Error(data.error || `HTTP error! status: ${response.status}`);
            }
            
            displayResults(data, outputElement);
        } catch (error) {
            loadingIndicator.style.display = 'none';
            errorMessage.style.display = 'block';
            errorMessage.innerHTML = `
                <h3>Error Processing Image</h3>
                <p>${error.message}</p>
                <p>Please check that all model files are present and valid.</p>
            `;
            outputElement.innerHTML = '';
        }
    };

    const displayResults = (data, outputElement) => {
        outputElement.innerHTML = '';
        
        const resultImage = document.createElement('img');
        resultImage.src = `data:image/jpeg;base64,${data.image}`;
        resultImage.classList.add('result-image');
        outputElement.appendChild(resultImage);

        if (data.results?.length > 0) {
            const resultsContainer = document.createElement('div');
            resultsContainer.classList.add('results-container');
            
            data.results.forEach((result, index) => {
                const resultText = document.createElement('p');
                resultText.textContent = `Face ${index + 1}: Age: ${result.age} (${result.age_pro.toFixed(2)}%), ` +
                                     `Gender: ${result.gender} (${result.gender_pro.toFixed(2)}%)`;
                resultsContainer.appendChild(resultText);
            });
            
            outputElement.appendChild(resultsContainer);
        } else {
            const noFaceMessage = document.createElement('p');
            noFaceMessage.textContent = 'No faces detected in the image.';
            outputElement.appendChild(noFaceMessage);
        }
    };

    fetch('/model_status')
        .then(response => response.json())
        .then(status => {
            if (!status.model_loaded) {
                errorMessage.style.display = 'block';
                errorMessage.innerHTML = `
                    <h3>Model Loading Error</h3>
                    <p>The required models failed to load. Please check:</p>
                    <ul>
                        ${Object.entries(status.files_found).map(([file, found]) => 
                            `<li>${file}: ${found ? '✅' : '❌'}</li>`
                        ).join('')}
                    </ul>
                `;
                // Disable buttons if models aren't loaded
                uploadBtn.disabled = true;
                cameraBtn.disabled = true;
            }
        })
        .catch(error => {
            console.error('Error checking model status:', error);
            errorMessage.style.display = 'block';
            errorMessage.textContent = 'Error checking model status. Please refresh the page.';
        });

    uploadBtn.addEventListener('click', () => {
        uploadPanel.style.display = 'block';
        cameraPanel.style.display = 'none';
        uploadOutput.innerHTML = '';
        errorMessage.style.display = 'none';
    });

    cameraBtn.addEventListener('click', () => {
        uploadPanel.style.display = 'none';
        cameraPanel.style.display = 'block';
        cameraOutput.innerHTML = '';
        errorMessage.style.display = 'none';

        if (video.srcObject) {
            video.srcObject.getTracks().forEach(track => track.stop());
        }

        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
                video.onloadedmetadata = () => {
                    video.play();
                    streaming = true;
                };
            })
            .catch(error => {
                console.error('Error accessing camera:', error);
                errorMessage.style.display = 'block';
                errorMessage.textContent = 'Error accessing camera. Please check permissions.';
            });
    });

    startCamera.addEventListener('click', () => {
        startCamera.style.display = 'none';
        stopCamera.style.display = 'block';

        captureInterval = setInterval(() => {
            if (!streaming) return;

            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
            const base64Image = canvas.toDataURL('image/jpeg').split(',')[1];

            loadingIndicator.style.display = 'block';

            processImage(base64Image, cameraOutput);

        }, 500);
    });

    stopCamera.addEventListener('click', () => {
        startCamera.style.display = 'block';
        stopCamera.style.display = 'none';
        clearInterval(captureInterval);
    });

    switchToCamera.addEventListener('click', () => {
        uploadPanel.style.display = 'none';
        cameraPanel.style.display = 'block';
        uploadOutput.innerHTML = '';
        errorMessage.style.display = 'none';

        if (!video.srcObject) {
            cameraBtn.click();
        }
    });

    switchToUpload.addEventListener('click', () => {
        uploadPanel.style.display = 'block';
        cameraPanel.style.display = 'none';
        cameraOutput.innerHTML = '';
        errorMessage.style.display = 'none';

        clearInterval(captureInterval);
        streaming = false;
        if (video.srcObject) {
            video.srcObject.getTracks().forEach(track => track.stop());
            video.srcObject = null;
        }
        startCamera.style.display = 'block';
        stopCamera.style.display = 'none';
    });

    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (file) {
            const reader = new FileReader();

            reader.onload = (e) => {
                const base64Image = e.target.result.split(',')[1];
                processImage(base64Image, uploadOutput);
            }
            reader.readAsDataURL(file);
        }
    });
});