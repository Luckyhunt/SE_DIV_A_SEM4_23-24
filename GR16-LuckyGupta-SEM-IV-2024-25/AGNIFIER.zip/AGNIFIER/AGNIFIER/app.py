from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
import base64
import tensorflow as tf
import mediapipe as mp
import logging
import os

app = Flask(__name__)

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
KERAS_MODELS_DIR = BASE_DIR
try:
    logger.debug(f"Current directory: {os.getcwd()}")
    logger.debug(f"Base directory: {BASE_DIR}")
    logger.debug(f"Looking for Keras models in: {KERAS_MODELS_DIR}")

    mp_face_detection = mp.solutions.face_detection
    face_detection = mp_face_detection.FaceDetection(min_detection_confidence=0.5)
    logger.info("MediaPipe face detection loaded successfully")

    age_model_path = os.path.join(KERAS_MODELS_DIR, "age_model.keras")
    gender_model_path = os.path.join(KERAS_MODELS_DIR, "gender_model.keras")

    if not os.path.exists(age_model_path):
        raise FileNotFoundError(f"Age model not found at {age_model_path}")
    if not os.path.exists(gender_model_path):
        raise FileNotFoundError(f"Gender model not found at {gender_model_path}")

    try:
        age_model = tf.keras.models.load_model(age_model_path)
        logger.info(f"Age model loaded. Input shape: {age_model.input_shape}")
    except Exception as age_error:
        logger.error(f"Error loading age model: {age_error}")
        raise

    try:
        gender_model = tf.keras.models.load_model(gender_model_path)
        logger.info(f"Gender model loaded. Input shape: {gender_model.input_shape}")
    except Exception as gender_error:
        logger.error(f"Error loading gender model: {gender_error}")
        raise

    MODEL_TYPE = "keras"
    MODEL_LOADED = True
    logger.info("Successfully loaded all Keras models")

except Exception as e:
    logger.error(f"Error loading Keras models: {e}")
    try:
        logger.debug(f"Looking for Caffe models in: {MODELS_DIR}")
        AGE_PROTO = os.path.join(MODELS_DIR, "age_deploy.prototxt")
        AGE_MODEL = os.path.join(MODELS_DIR, "age_net.caffemodel")
        GENDER_PROTO = os.path.join(MODELS_DIR, "gender_deploy.prototxt")
        GENDER_MODEL = os.path.join(MODELS_DIR, "gender_net.caffemodel")

        for file_path in [AGE_PROTO, AGE_MODEL, GENDER_PROTO, GENDER_MODEL]:
            if not os.path.exists(file_path):
                logger.error(f"Missing model file: {file_path}")

        age_net = cv2.dnn.readNetFromCaffe(AGE_PROTO, AGE_MODEL)
        gender_net = cv2.dnn.readNetFromCaffe(GENDER_PROTO, GENDER_MODEL)

        MODEL_TYPE = "caffe"
        MODEL_LOADED = True
        logger.info("Successfully loaded Caffe models")
    except Exception as caffe_e:
        print(f"Error loading Caffe models: {caffe_e}")
        MODEL_LOADED = False

AGE_BUCKETS = ['(0-2)', '(4-6)', '(8-12)', '(15-18)', '(19-24)', '(25-32)', '(38-43)', '(48-53)', '(60-100)']
def get_age_bucket_from_age(age):
        age = int(round(age))
        low = max(0, age - 5)
        high = age + 5
        return f"({low}-{high})"


def detect_age_gender(image):
    if not MODEL_LOADED:
        logger.error("Models not loaded")
        return []

    results = []
    try:
        ih, iw, _ = image.shape

        if MODEL_TYPE == "keras":
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            with mp.solutions.face_detection.FaceDetection(
                min_detection_confidence=0.5) as face_detector:
                detections = face_detector.process(rgb_image)

            if not hasattr(detections, 'detections') or not detections.detections:
                logger.info("No faces detected in the image")
                return []

            for i, detection in enumerate(detections.detections):
                try:
                    bbox = detection.location_data.relative_bounding_box
                    x = int(max(0, bbox.xmin * iw))
                    y = int(max(0, bbox.ymin * ih))
                    w = int(min(iw - x, bbox.width * iw))
                    h = int(min(ih - y, bbox.height * ih))

                    face_img = image[y:y+h, x:x+w]
                    if face_img.size == 0:
                        logger.warning(f"Skip face {i+1}: Empty region")
                        continue

                    face_img = cv2.resize(face_img, (64, 64))
                    face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB)
                    face_img = face_img.astype('float32') / 255.0
                    face_img = np.expand_dims(face_img, axis=0)

                    logger.debug(f"Preprocessed face shape: {face_img.shape}")

                    age_preds = age_model.predict(face_img, verbose=0)
                    gender_preds = gender_model.predict(face_img, verbose=0)

                    logger.debug(f"Raw Age Prediction: {age_preds[0][0]}")
                    logger.debug(f"Raw Gender Prediction: {gender_preds[0][0]}")

                    predicted_age = age_preds[0][0]
                    age = get_age_bucket_from_age(predicted_age)
                    gender_pro = float(gender_preds[0][0] * 100)
                    gender = "Male" if gender_preds[0][0] < 0.5 else "Female"

                    logger.debug(f"Face {i + 1} -> Age: {age}, Gender Prob: {gender_pro:.2f}% ({gender})")

                    results.append({
                        "person": f"Person {i + 1}",
                        "age": age,
                        "gender": gender,
                        "age_pro": float(predicted_age),
                        "gender_pro": float(gender_preds[0][0] * 100),
                        "bbox": [x, y, w, h]
                    })

                except Exception as face_error:
                    logger.error(f"Error processing face {i+1}: {str(face_error)}")
                    continue

        else:
            ih, iw, _ = image.shape
            MEAN_VALUES = (78.4263377603, 87.7689143744, 114.590278846)
            MODEL_MEAN_VALUES = (127.5, 127.5, 127.5)

            cascade_path = os.path.join(cv2.data.haarcascades, 'haarcascade_frontalface_default.xml')
            if not os.path.exists(cascade_path):
                logging.error(f"Cascade file not found at: {cascade_path}")
                return []

            face_cascade = cv2.CascadeClassifier(cascade_path)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            for i, (x, y, w, h) in enumerate(faces):
                face_img = image[y:y + h, x:x + w]
                if face_img.size == 0:
                    logging.warning("Skipping empty face region.")
                    continue

                blob = cv2.dnn.blobFromImage(face_img, 1.0, (227, 227), MODEL_MEAN_VALUES, swapRB=False)
                gender_net.setInput(blob)
                gender_preds = gender_net.forward()

                blob = cv2.dnn.blobFromImage(face_img, 1.0, (227, 227), MEAN_VALUES, swapRB=False)
                age_net.setInput(blob)
                age_preds = age_net.forward()

                gender_i = gender_preds[0].argmax()
                age_i = age_preds[0].argmax()

                gender = ['Male', 'Female'][gender_i]
                age = AGE_BUCKETS[age_i]

                results.append({
                    "person": f"Person {i + 1}",
                    "age": age,
                    "gender": gender,
                    "age_pro": float(age_preds[0][age_i] * 100),
                    "gender_pro": float(gender_preds[0][gender_i] * 100),
                    "bbox": [int(x), int(y), int(w), int(h)]
                })
    except Exception as e:
        logger.error(f"Error in detect_age_gender: {str(e)}")
        return []

    return results


@app.route('/', methods=['GET'])
def index():
    media_pipe_loaded = MODEL_LOADED
    return render_template('index.html', model_loaded=MODEL_LOADED, media_pipe_loaded=media_pipe_loaded)


@app.route('/process_image', methods=['POST'])
def process_image():
    if not MODEL_LOADED:
        return jsonify({'error': 'Models not loaded. Please check server configuration.'}), 503

    try:
        data = request.get_json()
        if not data or "image" not in data:
            return jsonify({"error": "No image data provided"}), 400

        image_data = data['image']
        try:
            decoded_image = base64.b64decode(image_data)
            image = cv2.imdecode(np.frombuffer(decoded_image, np.uint8), cv2.IMREAD_COLOR)

            if image is None:
                raise ValueError("Failed to decode image")

            if image.size == 0:
                raise ValueError("Empty image received")

        except Exception as e:
            logger.error(f"Image decoding error: {str(e)}")
            return jsonify({"error": "Invalid image format"}), 400

        best_results = []
        best_age_pro = 0.0
        best_gender_pro = 0.0

        for _ in range(2):
            results = detect_age_gender(image)
            if results:
                for result in results:
                    if result['age_pro'] > best_age_pro or result['gender_pro'] > best_gender_pro:
                        best_age_pro = result['age_pro']
                        best_gender_pro = result['gender_pro']
                        best_results = results

        if not best_results:
            return jsonify({
                "image": image_data,
                "results": [],
                "message": "No faces detected in the image"
            })

        for res in best_results:
            x, y, w, h = res["bbox"]
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
            label = f"{res['person']}: Age {res['age']} ({res['age_pro']:.2f}%), Gender {res['gender']} ({res['gender_pro']:.2f}%)"
            cv2.putText(image, label, (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        _, encoded_image = cv2.imencode('.jpg', image)
        image_base64 = base64.b64encode(encoded_image).decode('utf-8')

        return jsonify({"image": image_base64, "results": best_results})

    except Exception as e:
        logger.error(f"Processing error: {str(e)}")
        return jsonify({'error': 'Internal server error during image processing'}), 500


@app.route('/model_status')
def model_status():
    return jsonify({
        'model_loaded': MODEL_LOADED,
        'model_type': MODEL_TYPE if MODEL_LOADED else None,
        'keras_models_dir': KERAS_MODELS_DIR,
        'models_dir': MODELS_DIR,
        'files_found': {
            'age.h5': os.path.exists(os.path.join(KERAS_MODELS_DIR, "age.h5")),
            'gender.h5': os.path.exists(os.path.join(KERAS_MODELS_DIR, "gender.h5")),
            'age_deploy.prototxt': os.path.exists(os.path.join(MODELS_DIR, "age_deploy.prototxt")),
            'age_net.caffemodel': os.path.exists(os.path.join(MODELS_DIR, "age_net.caffemodel")),
            'gender_deploy.prototxt': os.path.exists(os.path.join(MODELS_DIR, "gender_deploy.prototxt")),
            'gender_net.caffemodel': os.path.exists(os.path.join(MODELS_DIR, "gender_net.caffemodel"))
        }
    })


if __name__ == '__main__':
    app.run(debug=True)